package com.example.nabd;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class ProtectActivity extends AppCompatActivity {

    private ImageView ivFood, ivMedicine;
    private CardView l1,l2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_protect);

      l1= findViewById(R.id.cardFood);
      l2 = findViewById(R.id.cardMedicine);

        // Set click listeners for navigation
        l1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToDetail("Food");
            }
        });

        l2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToDetail("Medicine");
            }
        });
    }

    private void navigateToDetail(String type) {
        Intent intent = new Intent(this, DetailActivity.class);
        intent.putExtra("type", type); // Pass type to DetailActivity
        startActivity(intent);
    }
}
