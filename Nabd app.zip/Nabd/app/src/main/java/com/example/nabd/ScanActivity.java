package com.example.nabd;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.yalantis.ucrop.UCrop;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ScanActivity extends AppCompatActivity {
    ImageView ivBack, ivImage;
    TextView tvUpload, tvCamera;
    AppCompatButton btnScan;
    CardView cvImage;
    ProgressDialog progressDialog;
    FirebaseAuth auth;
    DatabaseReference dbRefEcgHistory;
    StorageReference storageReference;
    private String imageUri = "";
    private final int PICK_IMAGE = 123;
    private Uri currentImageUri;
    private final int CAMERA_REQUEST_CODE = 102;
    private TFLiteModelHandler modelHandler;

    // Hardcoded class labels
    private final String[] labels = {"Abnormal_Heartbeat", "History_of_MI", "MI", "Normal"};

    private final ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    openCamera();
                } else {
                    Toast.makeText(ScanActivity.this, "Camera permission denied", Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan);

        // Initialize UI components
        ivBack = findViewById(R.id.ivBack);
        tvUpload = findViewById(R.id.tvUpload);
        tvCamera = findViewById(R.id.tvCamera);
        cvImage = findViewById(R.id.cvImage);
        ivImage = findViewById(R.id.ivImage);
        btnScan = findViewById(R.id.btnScan);

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle(getString(R.string.app_name));
        progressDialog.setMessage("Please wait...");
        progressDialog.setCancelable(false);
        auth = FirebaseAuth.getInstance();
        dbRefEcgHistory = FirebaseDatabase.getInstance().getReference("ECG_History");
        storageReference = FirebaseStorage.getInstance().getReference("ECG_Pictures");

        try {
            modelHandler = new TFLiteModelHandler(this);
        } catch (IOException e) {
            e.printStackTrace();
            showMessage("Model could not be loaded");
        }

        ivBack.setOnClickListener(view -> finish());
        tvUpload.setOnClickListener(view -> chooseImageFromGallery());
        tvCamera.setOnClickListener(view -> checkCameraPermission());
        btnScan.setOnClickListener(view -> {
            if (!imageUri.isEmpty()) {
                storeHistoryData();
            } else {
                Toast.makeText(ScanActivity.this, "No image selected", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void storeHistoryData() {
        SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy HH:mm:ss aa", Locale.getDefault());
        String currentDateAndTime = sdf.format(new Date());
        progressDialog.show();
        Uri uriImage = Uri.parse(imageUri);
        StorageReference imageRef = storageReference.child(uriImage.getLastPathSegment());
        imageRef.putFile(uriImage).addOnSuccessListener(taskSnapshot -> imageRef.getDownloadUrl().addOnSuccessListener(uri -> {
            String downloadUri = uri.toString();
            String historyId = dbRefEcgHistory.push().getKey();

            String predictionResult = predictImageResults(uriImage);

            ECGModel model = new ECGModel(historyId, auth.getCurrentUser().getUid(), currentDateAndTime, downloadUri, predictionResult);

            dbRefEcgHistory.child(historyId).setValue(model).addOnSuccessListener(unused -> {
                progressDialog.dismiss(); // Ensure progress dialog is dismissed
                Intent intent = new Intent(ScanActivity.this, ResultActivity.class);
                intent.putExtra("image", downloadUri);
                intent.putExtra("predictionResults", predictionResult);
                startActivity(intent);
            }).addOnFailureListener(e -> {
                progressDialog.dismiss(); // Dismiss on failure
                showMessage(e.getLocalizedMessage());
            });

        }).addOnFailureListener(e -> {
            progressDialog.dismiss();
            showMessage(e.getLocalizedMessage());
        })).addOnFailureListener(e -> {
            progressDialog.dismiss();
            showMessage(e.getLocalizedMessage());
        });
    }

    private String predictImageResults(Uri imageUri) {
        try {
            Bitmap bitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(imageUri));
            Bitmap resizedBitmap = Bitmap.createScaledBitmap(bitmap, 64, 64, true); // Updated to 64x64

            if (modelHandler != null) {
                float[] predictionResults = modelHandler.predictImage(resizedBitmap);
                return generatePredictionString(predictionResults);
            } else {
                return "Model handler not initialized";
            }
        } catch (IOException e) {
            e.printStackTrace();
            return "Error loading image";
        }
    }

    private String generatePredictionString(float[] results) {
        if (results.length != labels.length) {
            return "Label count does not match result count";
        }
        StringBuilder debugInfo = new StringBuilder("Prediction Scores:\n");
        for (int i = 0; i < results.length; i++) {
            debugInfo.append(labels[i]).append(": ").append(results[i]).append("\n");
        }
        System.out.println(debugInfo.toString());

        int predictedIndex = getMaxIndex(results);
        String predictedLabel = labels[predictedIndex];
        return "Predicted Condition: " + predictedLabel;
    }

    private int getMaxIndex(float[] array) {
        int maxIndex = 0;
        for (int i = 1; i < array.length; i++) {
            if (array[i] > array[maxIndex]) {
                maxIndex = i;
            }
        }
        return maxIndex;
    }

    private void checkCameraPermission() {
        if (ContextCompat.checkSelfPermission(
                ScanActivity.this,
                android.Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED) {
            openCamera();
        } else {
            requestPermissionLauncher.launch(android.Manifest.permission.CAMERA);
        }
    }

    private void chooseImageFromGallery() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(intent, PICK_IMAGE);
    }

    private void openCamera() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            File photoFile = createImageFile();
            if (photoFile != null) {
                Uri photoURI = FileProvider.getUriForFile(this, "com.example.nabd.fileprovider", photoFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                currentImageUri = photoURI;
                startActivityForResult(takePictureIntent, CAMERA_REQUEST_CODE);
            }
        }
    }

    private File createImageFile() {
        try {
            String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
            String imageFileName = "JPEG_" + timeStamp + "_";
            File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
            File image = File.createTempFile(imageFileName, ".jpg", storageDir);
            return image;
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            imageUri = "";
            if (requestCode == PICK_IMAGE) {
                Uri selectedImageUri = data.getData();
                if (selectedImageUri != null) {
                    startCrop(selectedImageUri);
                }
            } else if (requestCode == CAMERA_REQUEST_CODE) {
                if (currentImageUri != null) {
                    startCrop(currentImageUri);
                }
            } else if (requestCode == UCrop.REQUEST_CROP) {
                Uri croppedImageUri = UCrop.getOutput(data);
                if (croppedImageUri != null) {
                    imageUri = croppedImageUri.toString();
                    // Use Glide to display the image
                    Glide.with(this)
                            .load(croppedImageUri)
                            .into(ivImage);
                    cvImage.setVisibility(View.VISIBLE);
                    btnScan.setVisibility(View.VISIBLE);
                }
            }
        }
    }

    private void startCrop(Uri uri) {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        Uri destinationUri = Uri.fromFile(new File(getCacheDir(), timeStamp + "_cropped_image.jpg"));

        UCrop.Options options = new UCrop.Options();
        options.setFreeStyleCropEnabled(true);
        options.setShowCropFrame(true);
        options.setShowCropGrid(true);
        options.setToolbarColor(ContextCompat.getColor(this, android.R.color.black));
        options.setStatusBarColor(ContextCompat.getColor(this, android.R.color.black));
        options.setToolbarWidgetColor(ContextCompat.getColor(this, android.R.color.white));


        UCrop.of(uri, destinationUri)
                .withOptions(options)
                .withAspectRatio(0, 0)
                .withMaxResultSize(4500, 4500)
                .start(this);
    }


    private void showMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}