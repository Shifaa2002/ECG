package com.example.nabd;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.BulletSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {

    private TextView tvContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        tvContent = findViewById(R.id.tvContent);

        String type = getIntent().getStringExtra("type");

        SpannableStringBuilder content = new SpannableStringBuilder();

        if ("Food".equals(type)) {
            addTitle(content, "Foods to Avoid");
            addCustomBulletPoint(content, "Processed foods");
            addCustomBulletPoint(content, "High-sodium snacks (e.g., chips, canned soups)");
            addCustomBulletPoint(content, "Sugary drinks (e.g., sodas, sweetened teas)");
            addCustomBulletPoint(content, "Fatty or fried foods (e.g., deep-fried chicken, french fries)");
            addCustomBulletPoint(content, "Red and processed meats (e.g., bacon, sausages)");
            addCustomBulletPoint(content, "Refined grains (e.g., white bread, pastries)");
            addCustomBulletPoint(content, "Trans fats (e.g., margarine, packaged baked goods)");
            addCustomBulletPoint(content, "High-sugar desserts (e.g., cakes, candies)");
        } else if ("Medicine".equals(type)) {
            // Display medicine-related content to avoid with custom formatting
            addTitle(content, "Medicines to Avoid");
            addCustomBulletPoint(content, "Nonsteroidal anti-inflammatory drugs (NSAIDs)");
            addCustomBulletPoint(content, "Certain over-the-counter cold medications containing decongestants");
            addCustomBulletPoint(content, "Medications that increase blood pressure (e.g., pseudoephedrine)");
            addCustomBulletPoint(content, "Some pain relievers (e.g., ibuprofen, naproxen)");
            addCustomBulletPoint(content, "Medications that may cause fluid retention (e.g., certain steroids)");
            addCustomBulletPoint(content, "High-dose aspirin (unless prescribed)");
            addCustomBulletPoint(content, "Certain herbal supplements that interact with heart medications");
            addCustomBulletPoint(content, "Stimulants (e.g., diet pills)");
        } else {
            addTitle(content, "No Specific Details Available");
        }

        tvContent.setText(content);
    }

    private void addTitle(SpannableStringBuilder builder, String title) {
        SpannableString spannableTitle = new SpannableString(title + "\n\n");
        spannableTitle.setSpan(new ForegroundColorSpan(Color.parseColor("#114fa2")), 0, spannableTitle.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannableTitle.setSpan(new StyleSpan(Typeface.BOLD), 0, spannableTitle.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannableTitle.setSpan(new RelativeSizeSpan(1.3f), 0, spannableTitle.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        builder.append(spannableTitle);
    }
    private void addCustomBulletPoint(SpannableStringBuilder builder, String text) {
        SpannableString spannableText = new SpannableString("  " + text + "\n");
        int bulletColor = Color.parseColor("#4CAF50");
        int bulletRadius = 12;
        spannableText.setSpan(new BulletSpan(20, bulletColor, bulletRadius), 0, spannableText.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannableText.setSpan(new ForegroundColorSpan(Color.parseColor("#000000")), 0, spannableText.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannableText.setSpan(new RelativeSizeSpan(1.1f), 0, spannableText.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        builder.append(spannableText);
    }
}
