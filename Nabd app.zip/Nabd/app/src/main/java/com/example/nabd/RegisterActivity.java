package com.example.nabd;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterActivity extends AppCompatActivity {
    TextInputEditText etName, etEmail, etPhone, etPassword;
    String name, email, phone, password;
    ProgressDialog progressDialog;
    FirebaseAuth auth;
    DatabaseReference dbRefUsers;
    AppCompatButton btnRegister;
    LinearLayout llBottom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPhone = findViewById(R.id.etPhone);
        etPassword = findViewById(R.id.etPassword);
        btnRegister = findViewById(R.id.btnRegister);
        llBottom = findViewById(R.id.llBottom);

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle(getString(R.string.app_name));
        progressDialog.setMessage("Please wait...");
        progressDialog.setCancelable(false);

        auth = FirebaseAuth.getInstance();
        dbRefUsers = FirebaseDatabase.getInstance().getReference("Users");

        llBottom.setOnClickListener(view -> finish());

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                name = etName.getText().toString().trim();
                email = etEmail.getText().toString().trim();
                phone = etPhone.getText().toString().trim();
                password = etPassword.getText().toString().trim();

                if (name.isEmpty()) {
                    showMessage("Please enter userName");
                    return;
                }
                if (email.isEmpty()) {
                    showMessage("Please enter email");
                    return;
                }
                if (!(Patterns.EMAIL_ADDRESS).matcher(email).matches()) {
                    showMessage("Please enter email in correct format");
                    return;
                }
                if (phone.isEmpty()) {
                    showMessage("Please enter phone");
                    return;
                }
                if (password.isEmpty()) {
                    showMessage("Please enter strong password");
                    return;
                }

                progressDialog.show();
                auth.createUserWithEmailAndPassword(email, password).addOnSuccessListener(authResult -> {
                    UserModel model = new UserModel(auth.getCurrentUser().getUid(), name, email, phone, password);
                    dbRefUsers.child(auth.getCurrentUser().getUid()).setValue(model).addOnCompleteListener(task -> {
                        progressDialog.dismiss();
                        showMessage("Registered Successfully");
                        finish();
                    }).addOnFailureListener(e -> {
                        progressDialog.dismiss();
                        showMessage(e.getLocalizedMessage());
                    });
                }).addOnFailureListener(e -> {
                    progressDialog.dismiss();
                    showMessage(e.getLocalizedMessage());
                });

            }
        });

    }

    private void showMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

}