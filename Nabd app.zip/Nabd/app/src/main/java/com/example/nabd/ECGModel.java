package com.example.nabd;

public class ECGModel {
    private String id;
    private String userId;
    private String dateTime;
    private String imageUrl;
    private String predictionResult;

    // No-argument constructor (required by Firebase)
    public ECGModel() {
    }

    public ECGModel(String id, String userId, String dateTime, String imageUrl, String predictionResult) {
        this.id = id;
        this.userId = userId;
        this.dateTime = dateTime;
        this.imageUrl = imageUrl;
        this.predictionResult = predictionResult;
    }

    // Getters and setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getPredictionResult() {
        return predictionResult;
    }

    public void setPredictionResult(String predictionResult) {
        this.predictionResult = predictionResult;
    }
}
