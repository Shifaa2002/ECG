package com.example.nabd;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseException;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class HistoryActivity extends AppCompatActivity {
    ImageView ivBack;
    TextView tvNoDataFound;
    RecyclerView rvECG;
    ProgressDialog progressDialog;
    FirebaseAuth auth;
    DatabaseReference dbRefEcgHistory;
    List<ECGModel> list = new ArrayList<>();
    HistoryAdapter adapter;

    private static final String TAG = "HistoryActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        ivBack = findViewById(R.id.ivBack);
        tvNoDataFound = findViewById(R.id.tvNoDataFound);
        rvECG = findViewById(R.id.rvECG);

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle(getString(R.string.app_name));
        progressDialog.setMessage("Please wait...");
        progressDialog.setCancelable(false);
        auth = FirebaseAuth.getInstance();
        dbRefEcgHistory = FirebaseDatabase.getInstance().getReference("ECG_History");

        ivBack.setOnClickListener(view -> finish());
    }

    @Override
    public void onResume() {
        super.onResume();
        fetchECGHistoryData();
    }

    private void fetchECGHistoryData() {
        progressDialog.show();
        dbRefEcgHistory.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                progressDialog.dismiss();
                list.clear();
                if (snapshot.exists()) {
                    for (DataSnapshot ds : snapshot.getChildren()) {
                        try {
                            ECGModel model = ds.getValue(ECGModel.class);
                            if (model != null) {
                                // Debug logs to check the data
                                Log.d(TAG, "Fetched model: " + model.toString());
                                if (auth.getCurrentUser() != null && model.getUserId().equals(auth.getCurrentUser().getUid())) {
                                    list.add(model);
                                } else {
                                    Log.d(TAG, "User ID does not match or user is not authenticated.");
                                }
                            } else {
                                Log.d(TAG, "Fetched model is null.");
                            }
                        } catch (DatabaseException e) {
                            e.printStackTrace();
                        }
                    }

                    if (list.isEmpty()) {
                        tvNoDataFound.setVisibility(View.VISIBLE);
                        rvECG.setVisibility(View.GONE);
                    } else {
                        tvNoDataFound.setVisibility(View.GONE);
                        rvECG.setVisibility(View.VISIBLE);
                        setAdapter();
                    }
                } else {
                    tvNoDataFound.setVisibility(View.VISIBLE);
                    rvECG.setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressDialog.dismiss();
                Toast.makeText(HistoryActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setAdapter() {
        adapter = new HistoryAdapter(this, list);
        rvECG.setLayoutManager(new LinearLayoutManager(this));
        rvECG.setAdapter(adapter);
    }
}
