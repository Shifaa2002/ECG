package com.example.nabd;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class ResultActivity extends AppCompatActivity {
    ImageView ivBack;
    ImageView ivMain;
    TextView tvResult;
    String mainImage = "";
    String predictionResults = "";
    ImageView btn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        ivBack = findViewById(R.id.ivBack);
        ivMain = findViewById(R.id.ivMain);
        tvResult = findViewById(R.id.tvResult);
        btn = findViewById(R.id.button);
        TextView tvInstruction = findViewById(R.id.tvInstruction);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent  intent =new Intent(getApplicationContext(),ProtectActivity.class);
                startActivity(intent);
            }
        });

        ivBack.setOnClickListener(view -> finish());

        if (getIntent().getExtras() != null) {
            mainImage = getIntent().getStringExtra("image");
            predictionResults = getIntent().getStringExtra("predictionResults");

            // Extract and format the prediction result
            if (predictionResults != null) {
                predictionResults = predictionResults.replace("Predicted Condition: ", "").trim();
            }

            String displayResult = "Predicted Condition: " + (predictionResults != null ? predictionResults.toUpperCase() : "N/A");
            Glide.with(this).load(mainImage).into(ivMain);
            tvResult.setText(displayResult);

            String guidelineMessage = getGuidelineMessage(predictionResults);
            tvInstruction.setText(guidelineMessage);
        }
    }

    private String getGuidelineMessage(String predictionResult) {
        if (predictionResult == null) {
            return "No specific guidelines available. Please consult with your healthcare provider for personalized advice.";
        }

        switch (predictionResult.toLowerCase()) {
            case "normal":
                return "Your heart is healthy.\nContinue to maintain a balanced diet, regular exercise, and a stress-free lifestyle for optimal health.";
            case "mi":
                return "You have experienced a myocardial infarction.\nIt's critical to consult your cardiologist and follow their prescribed treatment and lifestyle changes.";
            case "history_of_mi":
                return "You have a history of myocardial infarction.\nRegular check-ups, medication adherence, and lifestyle adjustments are essential. Please follow up with your healthcare provider.";
            case "abnormal_heartbeat":
                return "Irregular heartbeat detected.\nConsider visiting a cardiologist for a detailed evaluation and potential treatment options.";
            default:
                return "No specific guidelines available.\nPlease consult with your healthcare provider for personalized advice.";
        }
    }
}
